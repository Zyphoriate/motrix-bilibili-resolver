# @motrix/plugin-api

TypeScript types for authoring [Motrix](https://motrix.app) plugins.

Motrix plugins run inside a QuickJS sandbox and never import a real npm
package at runtime — the host injects a `motrix:plugin-api` module into the
sandbox global scope. This package supplies:

- an **ambient module declaration** for `motrix:plugin-api` (`src/virtual-module.d.ts`),
  so `import { hooks, commands, log, ... } from 'motrix:plugin-api'` type-checks
  and autocompletes in your editor even though the specifier resolves to
  nothing on disk
- a small set of **runtime helper utilities** (`retry`, `debounce`,
  `withTimeout`) that plugins can import as regular code, bundled from
  `dist/index.js`

## Install

```bash
pnpm add -D @motrix/plugin-api
```

Add as a dev dependency only — the virtual module is a compile-time
declaration, and the host provides the real implementation at runtime. Only
the helper utilities (`retry`/`debounce`/`withTimeout`) end up in your
plugin's built output if you actually import them.

## Usage

```ts
import { hooks, log } from 'motrix:plugin-api'
import { withTimeout } from '@motrix/plugin-api'

hooks.beforeCreate(async (ctx) => {
  log.info('resolving', { url: ctx.uris[0] })
  return withTimeout(resolve(ctx), 5000)
})
```

## Stable post-hook delivery identity

Since 2.1, `afterComplete` and `onError` receive a durable delivery envelope:

```ts
hooks.afterComplete(async (ctx) => {
  log.info('download finalized', {
    deliveryId: ctx.delivery.id,
    occurrenceId: ctx.delivery.occurrenceId,
    filePath: ctx.filePath,
  })
})
```

`ctx.delivery.id` remains stable when Motrix retries the same delivery, while
`ctx.invocationId` identifies the individual attempt. Retry counters, lease
state, and scheduler diagnostics are intentionally not exposed to plugins.

Make sure `src/virtual-module.d.ts` is visible to the TypeScript compiler.
Installing this package is enough — its `files` entry ships the `.d.ts`
alongside `dist`, and TypeScript picks up ambient module declarations from
any `.d.ts` under `node_modules/@types` or reachable via `include`/`types`
in `node_modules/@motrix/plugin-api`.

## Plugin operations (unreleased)

`commands.registerOperation` and `OperationContext` are development-only additions. The context exposes scoped file/media methods, progress, cancellation and business errors; it does not grant access to arbitrary paths. Use the matching host implementation and the complete source examples.

See the [English guide](../../docs/operations.md) or [Chinese guide](../../docs/operations.zh-CN.md), including complete media and text examples, supported controls, limits and compatibility requirements. The examples target Motrix beta.48 or later (below 3.0.0), contingent on that release shipping the required features; this is not a claim of published support.

## Learn more

- Scaffold a new plugin with [`@motrix/plugin-cli`](https://www.npmjs.com/package/@motrix/plugin-cli)
  (`pnpm create motrix-plugin`)
- Manifest shape is validated against [`@motrix/plugin-manifest-schema`](https://www.npmjs.com/package/@motrix/plugin-manifest-schema)
